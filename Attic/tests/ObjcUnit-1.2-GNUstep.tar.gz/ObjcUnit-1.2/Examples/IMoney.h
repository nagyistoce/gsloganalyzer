@class Money;
@class MoneyBag;

@protocol IMoney
- (id<IMoney>)add:(id<IMoney>)money;
- (id<IMoney>)addMoney:(Money *)money;
- (id<IMoney>)addMoneyBag:(MoneyBag *)bag;

- (BOOL)isZero;

- (id<IMoney>)multiply:(int)factor;

- (id<IMoney>)negate;

- (id<IMoney>)subtract:(id<IMoney>)money;
@end
