#import <ObjcUnit/ObjcUnit.h>

@class NSMutableArray;

@interface NSMutableArrayTest : TestCase {
    NSMutableArray *empty;
    NSMutableArray *full;
}

@end
