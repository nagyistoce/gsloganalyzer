#import <ObjcUnit/ObjcUnit.h>

@class Adder;

@interface AdderTest : TestCase {
    Adder *adder;
}
@end
