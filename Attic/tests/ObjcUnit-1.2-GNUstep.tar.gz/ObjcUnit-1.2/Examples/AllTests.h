#import <ObjcUnit/ObjcUnit.h>

@interface AllTests : TestSuite

+ (AllTests *)suite;

@end
