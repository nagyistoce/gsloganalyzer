#import <ObjcUnit/ObjcUnit.h>

@class Money;
@class MoneyBag;

@interface MoneyTest : TestCase {
    Money *f12CHF;
    Money *f14CHF;
    Money *f7USD;
    Money *f21USD;
    MoneyBag *fMB1;
    MoneyBag *fMB2;
}

@end
