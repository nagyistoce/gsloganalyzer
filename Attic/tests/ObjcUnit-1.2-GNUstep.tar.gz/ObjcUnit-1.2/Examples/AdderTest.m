#import "AdderTest.h"

#import "Adder.h"

@implementation AdderTest

- (void)setUp {
    adder = [[Adder alloc] initWithInitialValue:5];
}

- (void)tearDown {
    [adder release];
}

- (void)testAdd {
    [self assertInt:[adder add:2] equals:7 message:@"Should have added correctly"];
}

@end
