#import "Adder.h"

@implementation Adder

- (id)initWithInitialValue:(int)anInitialValue {
    self = [super init];
    myInitialValue = anInitialValue;
    return self;
}

- (int)add:(int)value {
    return myInitialValue + value;
}

@end
