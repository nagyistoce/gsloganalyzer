#import <ObjcUnit/ObjcUnit.h>

@interface MyPersistentObjectTest : TestCase

@end
