#import "AllTests.h"

#import "AdderTest.h"
#import "NSMutableArrayTest.h"
#import "MoneyTest.h"
#import "MyPersistentObjectTest.h"

@implementation AllTests

+ (AllTests *)suite {
    return [[[self alloc] initWithName:@"All Example Tests"] autorelease];
}

- (id)initWithName:(NSString *)aName {
    self = [super initWithName:aName];

    [self addTest:[TestSuite suiteWithClass:[AdderTest class]]];
    [self addTest:[TestSuite suiteWithClass:[NSMutableArrayTest class]]];
    [self addTest:[TestSuite suiteWithClass:[MoneyTest class]]];
    [self addTest:[TestSuite suiteWithClass:[MyPersistentObjectTest class]]];

    return self;
}

@end
