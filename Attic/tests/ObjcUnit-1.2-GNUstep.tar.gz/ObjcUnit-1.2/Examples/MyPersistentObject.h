#import <Foundation/Foundation.h>

@interface MyPersistentObject : NSObject <NSCoding> {
    NSString *name;
    NSNumber *amount;
}

- (void)setName:(NSString *)name;
- (NSString *)name;

- (void)setAmount:(NSNumber *)amount;
- (NSNumber *)amount;

@end
