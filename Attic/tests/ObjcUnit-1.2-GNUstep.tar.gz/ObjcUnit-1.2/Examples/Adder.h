#import <Foundation/Foundation.h>

@interface Adder : NSObject {
    int myInitialValue;
}

- (id)initWithInitialValue:(int)anInitialValue;

- (int)add:(int)value;

@end
