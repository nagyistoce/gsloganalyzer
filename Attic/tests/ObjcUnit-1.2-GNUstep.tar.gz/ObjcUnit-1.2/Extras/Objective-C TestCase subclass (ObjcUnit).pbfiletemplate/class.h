//
//  �FILENAME�
//  �PROJECTNAME�
//
//  Created by �FULLUSERNAME� on �DATE�.
//  Copyright (c) 2001 �ORGANIZATIONNAME�. All rights reserved.
//

#import <ObjcUnit/ObjcUnit.h>


@interface �FILEBASENAMEASIDENTIFIER� : NSObject {

}

@end
