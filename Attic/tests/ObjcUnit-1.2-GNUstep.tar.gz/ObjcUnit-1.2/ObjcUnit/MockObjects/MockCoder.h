#import <Foundation/Foundation.h>

@class ExpectationGroup;

@interface MockCoder : NSCoder {
@private
    ExpectationGroup *expectations;
    NSEnumerator *decodedObjects;
}

- (void)addExpectedEncodedObject:(id)object;

- (void)addDecodedObject:(id)object;

- (void)verify;

@end
