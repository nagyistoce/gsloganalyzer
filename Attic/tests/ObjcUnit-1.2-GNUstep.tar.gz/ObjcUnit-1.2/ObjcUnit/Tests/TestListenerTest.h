#import <ObjcUnit/ObjcUnit.h>

@interface TestListenerTest : TestCase <TestListener> {
    TestResult *result;
    int startCount, failureCount, errorCount, endCount;
}

@end
