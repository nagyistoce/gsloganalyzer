#import <ObjcUnit/ObjcUnit.h>

@interface NSObjectObjcUnitAdditionsTest : TestCase

@end
