#import <ObjcUnit/ObjcUnit.h>

@interface AllTests : NSObject

+ (TestSuite *)suite;

@end
