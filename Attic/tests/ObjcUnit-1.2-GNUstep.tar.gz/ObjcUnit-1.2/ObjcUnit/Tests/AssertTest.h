#import <ObjcUnit/ObjcUnit.h>

@interface AssertTest : TestCase

@end
