#import <ObjcUnit/ObjcUnit.h>

@interface MockCoderTest : TestCase

@end
