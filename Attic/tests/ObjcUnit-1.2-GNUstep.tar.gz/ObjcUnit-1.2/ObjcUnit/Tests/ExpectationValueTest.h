#import <ObjcUnit/ObjcUnit.h>

@interface ExpectationValueTest : TestCase

@end
