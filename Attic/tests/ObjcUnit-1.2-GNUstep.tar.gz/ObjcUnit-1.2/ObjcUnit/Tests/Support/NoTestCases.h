#import <ObjcUnit/ObjcUnit.h>

@interface NoTestCases : TestCase { }
@end
