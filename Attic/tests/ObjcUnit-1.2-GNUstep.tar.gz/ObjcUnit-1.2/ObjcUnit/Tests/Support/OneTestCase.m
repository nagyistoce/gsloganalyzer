#import "OneTestCase.h"

@implementation OneTestCase

- (void)noTestCase {
}

- (void)testCase {
}

- (void)testCase:arg {
}

@end
