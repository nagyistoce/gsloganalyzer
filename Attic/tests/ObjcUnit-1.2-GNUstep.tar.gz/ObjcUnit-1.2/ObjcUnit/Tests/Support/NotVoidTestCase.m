#import "NotVoidTestCase.h"

@implementation NotVoidTestCase

- (int)testNotVoid {
    return 1;
}

- (void)testVoid {
}

@end
