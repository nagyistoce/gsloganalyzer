#import <ObjcUnit/ObjcUnit.h>

@interface OneTestCase : TestCase { }
@end
