#import <ObjcUnit/ObjcUnit.h>

@interface NotVoidTestCase : TestCase { }
@end
