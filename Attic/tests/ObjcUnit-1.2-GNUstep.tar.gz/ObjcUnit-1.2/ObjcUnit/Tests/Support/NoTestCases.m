#import "NoTestCases.h"

@implementation NoTestCases

- (void)noTestCase {
}

- (void)testCase:arg {
}

@end
