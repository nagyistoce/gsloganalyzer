#import <ObjcUnit/ObjcUnit.h>

#import "OneTestCase.h"

@interface InheritedTestCase : OneTestCase { }
@end
