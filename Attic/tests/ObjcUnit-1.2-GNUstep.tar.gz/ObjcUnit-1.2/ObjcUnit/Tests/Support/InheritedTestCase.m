#import "InheritedTestCase.h"

@implementation InheritedTestCase

- (void)test2 {
}

@end
