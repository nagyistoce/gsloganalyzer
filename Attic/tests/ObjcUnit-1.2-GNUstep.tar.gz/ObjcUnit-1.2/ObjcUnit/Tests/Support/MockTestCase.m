#import "MockTestCase.h"

@implementation MockTestCase

- (void)runTest {
    if (runTestRaisesException) [NSException raise:@"Error" format:nil];
    if (runTestFails) [self fail];
    wasRun = YES;
}

- (void)setUp {
    if (setUpRaisesException) [NSException raise:@"Error" format:nil];
}

- (void)tearDown {
    isTornDown = YES;
    if (tearDownRaisesException) [NSException raise:@"Error" format:nil];
}

@end

