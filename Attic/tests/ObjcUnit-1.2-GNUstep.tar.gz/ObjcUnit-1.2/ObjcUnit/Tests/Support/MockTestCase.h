#import <ObjcUnit/ObjcUnit.h>

@interface MockTestCase : TestCase { 
@public
    BOOL runTestRaisesException, runTestFails;
    BOOL setUpRaisesException, tearDownRaisesException;
    BOOL isTornDown, wasRun;
}
@end
