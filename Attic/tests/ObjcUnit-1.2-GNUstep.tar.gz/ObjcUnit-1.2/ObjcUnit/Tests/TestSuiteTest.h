#import <ObjcUnit/ObjcUnit.h>

@interface TestSuiteTest : TestCase {
    TestResult *result;
}

+ (TestSuite *)suite;

@end
