#import <ObjcUnit/ObjcUnit.h>

@interface ExpectationCounterTest : TestCase

@end
