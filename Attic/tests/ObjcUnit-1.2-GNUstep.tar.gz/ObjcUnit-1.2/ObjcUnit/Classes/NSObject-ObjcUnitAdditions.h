#import <Foundation/Foundation.h>

@interface NSObject (ObjcUnitAdditions)

+ (NSArray *)instanceMethodNames;

@end
