#import "AssertionFailedException.h"

@implementation AssertionFailedException

@end
