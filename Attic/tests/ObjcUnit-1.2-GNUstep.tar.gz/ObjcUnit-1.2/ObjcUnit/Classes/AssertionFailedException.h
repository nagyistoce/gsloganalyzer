#import <Foundation/Foundation.h>

@interface AssertionFailedException : NSException

@end
